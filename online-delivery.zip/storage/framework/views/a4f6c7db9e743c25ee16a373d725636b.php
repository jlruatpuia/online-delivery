<?php $__env->startSection('title', 'My Deliveries'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-pills card-header-pills mb-3">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#pending">
                        Pending (<?php echo e($pending->count()); ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#completed">
                        Completed (<?php echo e($completed->count()); ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#cancelled">
                        Cancelled (<?php echo e($cancelled->count()); ?>)
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="pending">
                    <div class="tab-pane fade show active" id="pending">
                        <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php echo $__env->make('mobile.deliveries._card', ['delivery' => $delivery], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted">
                                No pending deliveries
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="completed">

                    <?php $__empty_1 = true; $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('mobile.deliveries._card', ['delivery' => $delivery], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted">
                            No completed deliveries
                        </div>
                    <?php endif; ?>

                </div>
                <div class="tab-pane fade" id="cancelled">

                    <?php $__empty_1 = true; $__currentLoopData = $cancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('mobile.deliveries._card', ['delivery' => $delivery], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted">
                            No cancelled deliveries
                        </div>
                    <?php endif; ?>

                </div>
            </div> 
        </div>
    </div>




    <!-- LONG PRESS ACTION SHEET -->
    <div class="offcanvas offcanvas-bottom"
         tabindex="-1"
         id="deliveryActionSheet">
        <div class="offcanvas-header">
            <h6 class="fw-bold mb-0">Delivery Actions</h6>
            <button class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>

        <div class="offcanvas-body">
            <a id="actionCall" class="btn btn-outline-primary w-100 mb-2">
                📞 Call Customer
            </a>

            <a id="actionNavigate" class="btn btn-outline-success w-100 mb-2">
                📍 Navigate
            </a>

            <a id="actionOpen" class="btn btn-primary w-100">
                📦 Open Delivery
            </a>
        </div>
    </div>
    <script>
        let pressTimer;

        function startPress(e, openUrl, phone, mapLocation) {
            pressTimer = setTimeout(() => {

                // Set actions
                document.getElementById('actionOpen').href = openUrl;
                document.getElementById('actionCall').href = 'tel:' + phone;

                if (mapLocation) {
                    document.getElementById('actionNavigate').href ="<?php echo e($delivery['navigation_url']); ?>";
                    document.getElementById('actionNavigate').classList.remove('disabled');
                } else {
                    document.getElementById('actionNavigate').href = '#';
                    document.getElementById('actionNavigate').classList.add('disabled');
                }

                // Show bottom sheet
                new bootstrap.Offcanvas(
                    document.getElementById('deliveryActionSheet')
                ).show();

            }, 500); // 500ms = long press
        }

        function cancelPress() {
            clearTimeout(pressTimer);
        }
    </script>
    <script>
        document.querySelectorAll('.swipe-container').forEach(container => {
            const card = container.querySelector('.swipe-card');
            let startX = 0;
            let currentX = 0;
            let isSwiping = false;

            card.addEventListener('touchstart', e => {
                startX = e.touches[0].clientX;
                isSwiping = true;
            });

            card.addEventListener('touchmove', e => {
                if (!isSwiping) return;

                currentX = e.touches[0].clientX - startX;

                // limit swipe distance
                if (Math.abs(currentX) > 100) return;

                card.style.transform = `translateX(${currentX}px)`;
            });

            card.addEventListener('touchend', () => {
                isSwiping = false;

                // 👉 Swipe Right → Call
                if (currentX > 60) {
                    window.location.href = container.dataset.call;
                }

                // 👉 Swipe Left → Navigate
                else if (currentX < -60) {
                    
                    
                    
                    
                    
                    
                    
                    if (container.dataset.map) {
                        window.open(container.dataset.navigation,
                            '_blank'
                        );
                    }
                }

                // reset
                card.style.transform = 'translateX(0)';
                currentX = 0;
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobile.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/deliveries/index.blade.php ENDPATH**/ ?>