<div class="offcanvas offcanvas-end"
     tabindex="-1"
     id="notificationCanvas">

    <div class="offcanvas-header">
        <h5>🔔 Notifications</h5>
        <button type="button"
                class="btn-close"
                data-bs-dismiss="offcanvas"></button>
    </div>

    <div class="offcanvas-body p-0" id="notificationList">
        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="swipe-container mb-2" data-id="<?php echo e($n->id); ?>">
                <div class="swipe-bg">
                    ✔ Mark as read
                </div>

                <div class="swipe-card p-3 rounded <?php echo e($n->read_at ? 'bg-light' : 'bg-white fw-bold'); ?>">
                    <div class="small">
                        <?php echo e($n->data['title'] ?? 'Notification'); ?>

                    </div>
                    <small class="text-muted">
                        <?php echo e($n->created_at->diffForHumans()); ?>

                    </small>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted text-center">
                No Notifications
            </p>
        <?php endif; ?>
        <div class="p-3">
            <button id="markAllRead" class="btn btn-sm btn-outline-primary w-100">Mark all as Read</button>
        </div>

    </div>
</div>
<?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/notifications.blade.php ENDPATH**/ ?>