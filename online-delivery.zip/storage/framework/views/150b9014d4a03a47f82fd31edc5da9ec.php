<div class="offcanvas offcanvas-end"
     tabindex="-1"
     id="notificationCanvas">

    <div class="offcanvas-header">
        <h5>Notifications</h5>
        <button type="button"
                class="btn-close"
                data-bs-dismiss="offcanvas"></button>
    </div>

    <div class="offcanvas-body p-0">
        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-3 border-bottom
                <?php echo e($notification->read_at ? '' : 'bg-light'); ?>">
                <div class="small">
                    <?php echo e($notification->data['message'] ?? 'Notification'); ?>

                </div>
                <div class="text-muted small">
                    <?php echo e($notification->created_at->diffForHumans()); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-3 text-center text-muted">
                No notifications
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/notifications.blade.php ENDPATH**/ ?>