<?php $__env->startSection('title', 'Login | Rose Online Delivery'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center align-items-center vh-100">
        <div class="card shadow-sm w-100" style="max-width: 360px;">
            <div class="card-header">Delivery Login</div>
            <form method="POST" action="<?php echo e(route('mobile.login.submit')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label" for="username">Username</label>
                        <input type="text"
                               name="username"
                               id="username"
                               value="<?php echo e(old('username')); ?>"
                               class="form-control"
                               placeholder="Username"
                               required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="password">Password</label>
                        <input type="password"
                               id="password"
                               name="password"
                               class="form-control"
                               placeholder="Password"
                               required>
                    </div>

                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mb-2">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary w-100">
                        Login
                    </button>
                </div>
            </form>
        </div>
    </div>













<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobile.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/auth/login.blade.php ENDPATH**/ ?>