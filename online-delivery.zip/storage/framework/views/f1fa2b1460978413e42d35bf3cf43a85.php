<?php $__env->startSection('title', 'Performance'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">

        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Delivery Boys</li>
                            <li class="breadcrumb-item active" aria-current="page">Performance</li>
                        </ol>
                    </nav>
                    <h1 class="m-0">Delivery Boys</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid page__container">
            <form method="get">
                <div class="card card-form d-flex flex-column flex-sm-row">
                    <div class="card-form__body card-body-form-group flex">
                        <div class="row">
                            <div class="col-sm-auto">
                                <div class="form-group" style="width: 200px;">
                                    <label for="dateRange">Select Date Range</label>
                                    <input type="text" id="dateRange"
                                           name="date_range"
                                           class="form-control" placeholder="Select Date Range"
                                           value="<?php echo e(request('date_range')); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn bg-white border-left border-top border-top-sm-0 rounded-top-0 rounded-top-sm rounded-left-sm-0"><i class="material-icons text-primary icon-20pt">refresh</i>
                    </button>

                </div>
            </form>
            <div class="card">
                <h5 class="card-header">Delivery Boys Performance</h5>
                <div class="card-body">
                    <table id="performanceTable"
                           class="table table-bordered table-hover align-middle">
                        <thead>
                        <tr>
                            <th>Delivery Boy</th>
                            <th>Total</th>
                            <th>Delivered</th>
                            <th>Cancelled</th>
                            <th>Rescheduled</th>
                            <th>Success %</th>
                            <th>Total Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $performance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-href="<?php echo e(route('admin.delivery_boys.performance.show', $row['id'])); ?>"
                                style="cursor:pointer">
                                <td><?php echo e($row['name']); ?></td>
                                <td><?php echo e($row['total']); ?></td>
                                <td class="text-success"><?php echo e($row['delivered']); ?></td>
                                <td class="text-danger"><?php echo e($row['cancelled']); ?></td>
                                <td class="text-warning"><?php echo e($row['rescheduled']); ?></td>
                                <td><?php echo e($row['success_rate']); ?>%</td>
                                <td class="fw-bold">₹ <?php echo e(number_format($row['total_amount'], 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        flatpickr("#dateRange", {
            mode: "range",
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "d-m-Y",
            maxDate: "today",
            defaultDate: [
                "<?php echo e(now()->startOfMonth()->toDateString()); ?>",
                "<?php echo e(now()->toDateString()); ?>"
            ]
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#performanceTable').DataTable({
                pageLength: 10,
                ordering: true,
                searching: true,
                lengthChange: false,

            });
        });
    </script>
    <script>
        document.querySelectorAll('#performanceTable tbody tr')
            .forEach(row => {
                row.addEventListener('click', () => {
                    window.location = row.dataset.href;
                });
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/delivery_boys/performance.blade.php ENDPATH**/ ?>