<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="mdk-drawer-layout__content page">

        <div class="container-fluid page__heading-container">
            <div class="page__heading">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="#">
                                <i class="fa fa-tachometer-alt"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
                <h1 class="m-0">Dashboard</h1>
            </div>
        </div>


        <div class="container-fluid page__container">
            <div class="row card-group-row">
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center bg-primary-subtle">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Total Deliveries</div>
                            <div class="text-amount"><?php echo e($stats['total']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">box</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Delivered</div>
                            <div class="text-amount"><?php echo e($stats['delivered']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">hand_package</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Pending</div>
                            <div class="text-amount"><?php echo e($stats['pending']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">pending_actions</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Cancelled</div>
                            <div class="text-amount"><?php echo e($stats['cancelled']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">enterprise_off</i></div>
                    </div>
                </div>
            </div>
            <div class="row card-group-row">
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Cancelled</div>
                            <div class="text-amount"><?php echo e($stats['cancelled']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">enterprise_off</i></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Rescheduled</div>
                            <div class="text-amount"><?php echo e($stats['rescheduled']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">edit_calendar</i></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">Amount</div>
                            <div class="text-amount">₹ <?php echo e(number_format($stats['total_amount'], 2)); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">money_range</i></div>
                    </div>
                </div>
            </div>

            <div class="card">
                <h5 class="card-header">Delivery Boy Summary</h5>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Total</th>
                            <th>Delivered</th>
                            <th>Pending</th>
                            <th>Cancelled</th>
                            <th>Rescheduled</th>
                            <th>Total Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $deliveryBoys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($boy->name); ?></td>
                                <td><?php echo e($boy->total_deliveries); ?></td>
                                <td class="text-success"><?php echo e($boy->delivered_count); ?></td>
                                <td class="text-warning"><?php echo e($boy->pending_count); ?></td>
                                <td class="text-danger"><?php echo e($boy->cancelled_count); ?></td>
                                <td class="text-secondary"><?php echo e($boy->rescheduled_count); ?></td>
                                <td>₹ <?php echo e(number_format($boy->total_amount ?? 0, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <!-- Delivery Status Chart -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>Delivery Status</h6>
                                    <canvas id="deliveryStatusChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <!-- Delivery Boy Performance Chart -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>Delivery Boy Performance</h6>
                                    <canvas id="deliveryBoyChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>Payment Type (Cash vs UPI)</h6>
                                    <canvas id="paymentTypeChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        const deliveryStatusData = <?php echo json_encode($deliveryStatus, 15, 512) ?>;

        new Chart(
            document.getElementById('deliveryStatusChart'),
            {
                type: 'doughnut',
                data: {
                    labels: Object.keys(deliveryStatusData),
                    datasets: [{
                        data: Object.values(deliveryStatusData),
                    }]
                }
            }
        );

        const performanceData = <?php echo json_encode($deliveryBoyPerformance, 15, 512) ?>;

        new Chart(
            document.getElementById('deliveryBoyChart'),
            {
                type: 'bar',
                data: {
                    labels: performanceData.map(x => x.name),
                    datasets: [
                        {
                            label: 'Total Deliveries',
                            data: performanceData.map(x => x.total)
                        },
                        {
                            label: 'Delivered',
                            data: performanceData.map(x => x.delivered)
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            }
        );

        const paymentData = <?php echo json_encode($paymentSummary, 15, 512) ?>;

        new Chart(
            document.getElementById('paymentTypeChart'),
            {
                type: 'doughnut',
                data: {
                    labels: Object.keys(paymentData).map(x =>
                        x.toUpperCase()
                    ),
                    datasets: [{
                        data: Object.values(paymentData)
                    }]
                }
            }
        );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>