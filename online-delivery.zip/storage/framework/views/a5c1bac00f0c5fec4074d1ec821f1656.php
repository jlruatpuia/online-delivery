<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">

        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Profile</li>
                        </ol>
                    </nav>
                    <h1 class="mt-2"><?php echo e(auth()->user()->name); ?> – Profile</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid page__container">
            <form method="POST"
                  action="<?php echo e(route('admin.profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card card-form">
                    <div class="row no-gutters">
                        <div class="col-lg-4 card-body">
                            <p><strong class="headings-color">Basic Information</strong></p>
                            <p class="text-muted">Edit your account details and settings.</p>
                        </div>
                        <div class="col-lg-8 card-form__body card-body">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input id="name" name="name" type="text" class="form-control" placeholder="Name" value="<?php echo e(old('name', $user->name)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input id="username" name="username" type="text" class="form-control" placeholder="Username" value="<?php echo e(old('username', $user->username)); ?>">
                            </div>
                            <button class="btn btn-primary">
                                Save Profile
                            </button>
                        </div>

                    </div>
                </div>
            </form>
            <form method="POST"
                  action="<?php echo e(route('admin.profile.password')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card card-form">
                    <div class="row no-gutters">
                        <div class="col-lg-4 card-body">
                            <p><strong class="headings-color">Update Your Password</strong></p>
                            <p class="text-muted">Change your password.</p>
                        </div>
                        <div class="col-lg-8 card-form__body card-body">
                            <div class="form-group">
                                <label for="opass">Old Password</label>
                                <input style="width: 270px;" id="opass" name="current_password" type="password" class="form-control" placeholder="Current Password" required>
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger">
                                    <?php echo e($message); ?>

                                </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="npass">New Password</label>
                                <input style="width: 270px;" id="npass" name="password" type="password" class="form-control" placeholder="New Password" required>
                            </div>
                            <div class="form-group">
                                <label for="cpass">Confirm Password</label>
                                <input style="width: 270px;" id="cpass" name="password_confirmation" type="password" class="form-control" placeholder="Confirm Password" required>
                            </div>
                            <button class="btn btn-warning">
                                Change Password
                            </button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#performanceTable').DataTable({
                pageLength: 10,
                ordering: true,
                searching: true,
                lengthChange: true,

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/profile.blade.php ENDPATH**/ ?>