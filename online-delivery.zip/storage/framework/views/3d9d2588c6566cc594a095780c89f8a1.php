<?php $__env->startSection('title', 'Delivery Detail'); ?>
<?php $__env->startSection('content'); ?>

    <?php
    $status = $delivery->status;

    $color = null;
    switch($status) {
        case "pending":
            $color = 'warning';
            break;
        case "delivered":
            $color = 'success';
            break;
        case "cancelled":
            $color = 'danger';
            break;
        case 'reschedule_requested':
            $color = 'info';
            break;
        case 'cancel_requested':
            $color = 'info';
            break;
    }
    ?>

    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Deliveries</li>
                            <li class="breadcrumb-item active" aria-current="page">Detail</li>
                        </ol>
                    </nav>
                    <h1 class="m-0">Delivery Detail</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid page__container">
            <div class="card border border-<?php echo e($color); ?>">
                <h5 class="card-header">
                    Delivery Detail
                </h5>
                <div class="card-body p-3">
                    <div class="row mb-2">
                        <div class="col-2"><strong>Invoice No:</strong></div>
                        <div class="col-10"> <?php echo e($delivery->invoice_no); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Delivery Date:</strong></div>
                        <div class="col-10"> <?php echo e($delivery->delivery_date->format('d M Y')); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Delivery Boy:</strong></div>
                        <div class="col-10"> <?php echo e($delivery->deliveryBoy->name); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Amount:</strong></div>
                        <div class="col-10"> ₹ <?php echo e(number_format($delivery->amount, 2)); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Payment Type:</strong></div>
                        <div class="col-10"> <?php echo e(strtoupper($delivery->payment_type)); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Status:</strong></div>
                        <div class="col-10"> <?php echo e(ucfirst(str_replace('_', ' ', ucwords($status, '_')))); ?> </div>
                    </div>
                    <?php if($delivery->status == 'delivered'): ?>
                        <div class="row mb-2">
                            <div class="col-2"><strong>Payment Method:</strong></div>
                            <div class="col-10"> <?php echo e(strtoupper($delivery->payment->payment_method)); ?> </div>
                        </div>
                    <?php endif; ?>
                    <hr>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Customer Name:</strong></div>
                        <div class="col-10"> <?php echo e(ucfirst($delivery->customer->name)); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Address:</strong></div>
                        <div class="col-10"> <?php echo e(ucfirst($delivery->customer->address)); ?> </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-2"><strong>Phone No:</strong></div>
                        <div class="col-10"> <?php echo e(ucfirst($delivery->customer->phone_no)); ?> </div>
                    </div>

                    <?php if($status === 'reschedule_requested'): ?>
                        <hr/>
                        <div class="row mb-2  d-flex align-items-center">
                            <div class="col-2"><strong>Reschedule Date:</strong></div>
                            <div class="col-10"> <?php echo e($delivery->rescheduled_at->format('d M Y')); ?> </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($status === 'reschedule_requested' || $status === 'cancel_requested'): ?>
                <div class="card-footer">
                    <form method="post" action="<?php echo e(route('admin.deliveries.approve', $delivery)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary">Approve</button>
                    </form>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <!-- Reject Modal -->



























<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/deliveries/show.blade.php ENDPATH**/ ?>