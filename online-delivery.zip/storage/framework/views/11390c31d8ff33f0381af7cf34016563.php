<?php $__env->startSection('title', 'Performance Detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">

        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Delivery Boys</li>
                            <li class="breadcrumb-item">Performance</li>
                            <li class="breadcrumb-item active" aria-current="page">Detail</li>
                        </ol>
                    </nav>
                    <h1 class="mt-2"><?php echo e($user->name); ?> – Performance Detail</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid page__container">
            <div class="row card-group-row">
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center bg-primary-subtle">
                        <div class="flex">
                            <div class="card-header__title text-warning mb-2">Pending</div>
                            <div class="text-amount"><?php echo e($statusCounts['pending']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">pending_actions</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-success mb-2">Delivered</div>
                            <div class="text-amount"><?php echo e($statusCounts['delivered']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">hand_package</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-info mb-2">Rescheduled</div>
                            <div class="text-amount"><?php echo e($statusCounts['rescheduled']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">pending_actions</i></div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-danger mb-2">Cancelled</div>
                            <div class="text-amount"><?php echo e($statusCounts['cancelled']); ?></div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">enterprise_off</i></div>
                    </div>
                </div>
            </div>
            <div class="row card-group-row">
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center bg-primary-subtle">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">💵 COD</div>
                            <div class="text-amount">₹ <?php echo e(number_format($codAmount, 2)); ?></div>
                            <div class="text-stats text-primary"><?php echo e($codCount); ?> orders</div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">currency_exchange</i></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">💳 Prepaid</div>
                            <div class="text-amount">₹ <?php echo e(number_format($prepaidAmount, 2)); ?></div>
                            <div class="text-stats text-primary"><?php echo e($prepaidCount); ?> orders</div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">money_off</i></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 card-group-row__col">
                    <div class="card card-group-row__card card-body card-body-x-lg flex-row align-items-center">
                        <div class="flex">
                            <div class="card-header__title text-muted mb-2">💰 Total Amount</div>
                            <div class="text-amount">₹ <?php echo e(number_format($totalAmount, 2)); ?></div>
                            <div class="text-stats text-primary"><?php echo e($totalCount); ?> orders</div>
                        </div>
                        <div><i class="material-symbols-outlined icon-muted icon-40pt ml-3">score</i></div>
                    </div>
                </div>
            </div>
            <!-- 📦 Delivery Status Summary -->


            <div class="card">
                <h5 class="card-header">Period: <?php echo e(\Carbon\Carbon::parse($from)->format('d M Y')); ?> → <?php echo e(\Carbon\Carbon::parse($to)->format('d M Y')); ?></h5>
                <div class="card-body">
                    <table id="performanceTable" class="table table-bordered align-middle">
                        <thead>
                        <tr>
                            <th>Invoice</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->invoice_no); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($d->delivery_date)->format('d-M-Y')); ?></td>
                                <td><?php echo e(ucfirst($d->status)); ?></td>
                                <td><?php echo e(strtoupper($d->payment_type ?? '-')); ?></td>
                                <td>₹ <?php echo e(number_format($d->amount, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#performanceTable').DataTable({
                pageLength: 10,
                ordering: true,
                searching: true,
                lengthChange: true,

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/delivery_boys/show.blade.php ENDPATH**/ ?>