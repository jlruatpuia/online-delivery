<?php
    $statusConfig = [
        'pending' => ['warning', 'Pending'],
        'assigned' => ['primary', 'Assigned'],
        'delivered' => ['success', 'Delivered'],
        'cancelled' => ['danger', 'Cancelled'],
        'cancel_requested' => ['danger', 'Cancel Requested'],
        'reschedule_requested' => ['secondary', 'Reschedule Requested'],
    ];

    [$badgeColor, $statusLabel] =
        $statusConfig[$delivery['status']]
        ?? ['dark', ucfirst($delivery['status'])];

    $isUrgent =
        in_array($delivery['status'], ['pending','assigned']) &&
        $delivery['created_at']->diffInHours(now()) >= 2;

    $hasMap = !empty($delivery['has_map_location']);
    $customer = $delivery['customer'] ?? null;
?>

<div class="swipe-container mb-3"
     data-call="tel:<?php echo e($delivery['customer']['phone'] ?? ''); ?>"
     data-navigation="<?php echo e($delivery['navigation_url'] ?? ''); ?>">


    <!-- LEFT ACTION -->
    <div class="swipe-action swipe-left">
        📞 Call
    </div>

    <!-- RIGHT ACTION -->
    <div class="swipe-action swipe-right">
        📍 Navigate
    </div>

    <!-- CARD (NOT CLICKABLE) -->
    <div class="card swipe-card shadow-sm
                <?php echo e($isUrgent ? 'border-danger' : ''); ?>"
         oncontextmenu="return false"
         ontouchstart="startPress(event,
            '<?php echo e(route('mobile.delivery.show', $delivery['id'])); ?>',
            '<?php echo e($delivery['customer']['phone']); ?>',
            '<?php echo e($delivery['navigation_url']); ?>'
         )"
         ontouchend="cancelPress()"
         onmousedown="startPress(event,
            '<?php echo e(route('mobile.delivery.show', $delivery['id'])); ?>',
            '<?php echo e($delivery['customer']['phone']); ?>',
            '<?php echo e($delivery['navigation_url']); ?>'
         )"
         onmouseup="cancelPress()"
    >
        <div class="card-header d-flex justify-content-between align-items-start">
            <div>
                <strong>#<?php echo e($delivery['invoice_no']); ?></strong>

                
                <?php if($delivery['payment_type'] === 'prepaid'): ?>
                    <span class="ms-1">💳</span>
                <?php else: ?>
                    <span class="ms-1">💵</span>
                <?php endif; ?>
            </div>

            
            <span class="badge bg-<?php echo e($badgeColor); ?>">
                <?php echo e($statusLabel); ?>

            </span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-8">
                    
                    <?php if($isUrgent): ?>
                        <span class="badge bg-danger mb-2">🔔 Urgent</span>
                    <?php endif; ?>

                    
                    <div class="fw-semibold text-success">
                        ₹ <?php echo e(number_format($delivery['amount'], 2)); ?>

                    </div>

                    
                    <div class="small text-muted">
                        <i class="bi bi-person"></i>
                        <?php echo e($delivery['customer']['name']); ?>

                    </div>
                    <div class="small text-muted">
                        <i class="bi bi-geo-alt"></i>
                        <?php echo e($delivery['customer']['address']); ?>

                    </div>
                    
                    <div class="small text-muted mb-1">
                        <i class="bi bi-clock"></i>
                        <?php echo e($delivery['created_at']->format('d M Y, h:i A')); ?>

                    </div>
                </div>
                <div class="col-4">
                    
                    <?php if($hasMap): ?>
                        <a href="<?php echo e($delivery['navigation_url']); ?>"
                           target="_blank" class="d-block mt-2">
                            <img src="<?php echo e($delivery['staticMapUrl']); ?>"
                                 class="img-fluid rounded border"
                                 alt="Map Preview"
                                 style="max-height:220px; object-fit: cover"
                            >
                        </a>
                    <?php endif; ?>
                </div>
            </div>



        </div>
        <div class="card-footer">
            

            <a href="<?php echo e(route('mobile.delivery.show', $delivery['id'])); ?>"
               class="btn btn-primary-subtle w-100"
               >
                
                <i class="bi bi-eye fs-3"></i>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/deliveries/_card.blade.php ENDPATH**/ ?>