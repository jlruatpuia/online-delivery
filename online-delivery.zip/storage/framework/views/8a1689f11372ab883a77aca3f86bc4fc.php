<div class="navbar navbar-expand-sm navbar-main navbar-dark bg-dark  pr-0" id="navbar" data-primary>
    <div class="container-fluid p-0">

        <!-- Navbar toggler -->

        <button class="navbar-toggler navbar-toggler-right d-block d-md-none" type="button" data-toggle="sidebar">
            <span class="navbar-toggler-icon"></span>
        </button>


        <!-- Navbar Brand -->
        <a href="/admin/dashboard" class="navbar-brand ">
            <img class="navbar-brand-icon" src="<?php echo e(asset('dist/images/logo-sm.png')); ?>" width="22" alt="Stack">
            <span>Rose Online Delivery</span>
        </a>

        <ul class="nav navbar-nav ml-auto d-none d-md-flex">
            <li class="nav-item">
                <a href="<?php echo e(route('admin.upi')); ?>" class="nav-link" title="UPI Settings">

                    <span class="material-symbols-outlined nav-icon">
upi_pay
</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <?php
                $count = auth()->user()->unreadNotifications->count();
                ?>
                <a href="#notifications_menu" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">
                    <i class="material-icons nav-icon <?php if($count>0): ?> navbar-notifications-indicator <?php endif; ?>">notifications</i>
                </a>
                <div id="notifications_menu" class="dropdown-menu dropdown-menu-right navbar-notifications-menu">
                    <div class="dropdown-item d-flex align-items-center py-2">
                        <span class="flex navbar-notifications-menu__title m-0">Notifications</span>
                        <?php if($count > 0): ?>
                            <button id="adminMarkAllRead"
                                    class="btn btn-sm btn-outline-primary">
                                Mark all
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="navbar-notifications-menu__content" data-simplebar>
                        <div class="py-2">
                            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="dropdown-item admin-notif-item"
                                    data-id="<?php echo e($n->id); ?>"
                                     data-settlement="<?php echo e($n->data['settlement_id'] ?? ''); ?>"
                                     data-delivery="<?php echo e($n->data['delivery_id'] ?? ''); ?>"
                                >
                                    <div class="mr-3 fw-bold">
                                        <?php echo e($n->data['title'] ?? 'Notification'); ?>

                                    </div>

                                        <div class="small text-muted">
                                            <?php echo e($n->data['message'] ?? ''); ?>

                                        </div>
                                        <small class="text-muted">
                                            <?php echo e($n->created_at->diffForHumans()); ?>

                                        </small>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted text-center">
                                    No notifications
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </li>
        </ul>

        <ul class="nav navbar-nav d-none d-sm-flex border-left navbar-height align-items-center">
            <li class="nav-item dropdown">
                <a href="#account_menu" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">
                    <img src="<?php echo e(asset('dist/images/avatar/demi.png')); ?>" class="rounded-circle" width="32" alt="Frontted">
                    <span class="ml-1 d-flex-inline">
                        <span class="text-light"><?php echo e(auth()->user()->name); ?></span>
                    </span>
                </a>
                <div id="account_menu" class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-item-text dropdown-item-text--lh">
                        <div><strong><?php echo e(auth()->user()->name); ?></strong></div>
                        <div><?php echo e(auth()->user()->role); ?></div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('admin.profile.edit')); ?>">Edit Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>

    </div>
</div>
<?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/navbar.blade.php ENDPATH**/ ?>