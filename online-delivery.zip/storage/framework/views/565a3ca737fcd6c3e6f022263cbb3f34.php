<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- WELCOME -->
    <div class="mb-3">
        <h5 class="fw-bold mb-0">
            Welcome, <?php echo e(auth()->user()->name); ?> 👋
        </h5>
        <small class="text-muted">
            Have a safe delivery today
        </small>
    </div>
    <div id="dashboard-content">
    <!-- DELIVERY COUNTS -->
        <div class="row g-3 mb-3">
            <div class="col-6">
                <div class="card shadow-sm text-center">
                    <div class="card-body">
                        <h3 class="text-warning"><?php echo e($pendingCount); ?></h3>
                        <div class="small text-muted">Pending</div>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card shadow-sm text-center">
                    <div class="card-body">
                        <h3 class="text-success"><?php echo e($completedCount); ?></h3>
                        <div class="small text-muted">Completed</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PAYMENT SUMMARY -->
        <div class="card shadow-sm mb-3">
            <div class="card-header fw-semibold">
                Collections
            </div>
            <div class="card-body">


                <div class="d-flex justify-content-between mb-2">
                    <span>Prepaid</span>
                    <strong>₹ <?php echo e(number_format($totalPrepaid, 2)); ?></strong>
                </div>

                <div class="d-flex justify-content-between mb-2">
                    <span>Cash</span>
                    <strong>₹ <?php echo e(number_format($totalCash, 2)); ?></strong>
                </div>

                <div class="d-flex justify-content-between">
                    <span>UPI</span>
                    <strong>₹ <?php echo e(number_format($totalUpi, 2)); ?></strong>
                </div>

            </div>
            <div class="card-footer d-flex justify-content-between">
                <span class="fw-semibold">NET TOTAL</span>
                <span class="fw-semibold">₹ <?php echo e(number_format($netTotal, 2)); ?></span>
            </div>
        </div>

        <!-- RECENT ACTIVITIES -->
        <div class="card shadow-sm">
            <div class="card-header fw-semibold">Recent Deliveries</div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $recentDeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between border-bottom py-2">
                        <div>
                            <div class="fw-semibold">
                                Invoice #<?php echo e($delivery->invoice_no); ?>

                            </div>
                            <small class="text-muted">
                                <?php echo e(ucfirst(str_replace('_', ' ', $delivery->status))); ?>

                            </small>
                        </div>

                        <div class="text-end">
                            <div>₹ <?php echo e(number_format($delivery->amount, 2)); ?></div>
                            <small class="text-muted">
                                <?php echo e($delivery->created_at->diffForHumans()); ?>

                            </small>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted">
                        No recent activity
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        setInterval(() => {
            fetch("<?php echo e(route('mobile.dashboard')); ?>", {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(res => res.text())
                .then(html => {
                    document.getElementById('dashboard-content').innerHTML =
                        new DOMParser()
                            .parseFromString(html, 'text/html')
                            .getElementById('dashboard-content')
                            .innerHTML;
                });
        }, 30000); // refresh every 30 seconds
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobile.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/dashboard.blade.php ENDPATH**/ ?>