<?php $__env->startSection('title', 'Deliveries'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">

        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Deliveries</li>
                        </ol>
                    </nav>
                    <h1 class="m-0">Deliveries</h1>
                </div>
            </div>
        </div>
        <div class="container-fluid page__container">
            <form method="get">
                <div class="card card-form d-flex flex-column flex-sm-row">
                    <?php
                        $defaultFrom = now()->startOfMonth()->toDateString();
                        $defaultTo   = now()->toDateString();
                    ?>
                    <div class="card-form__body card-body-form-group flex">
                        <div class="row">
                            <div class="col-sm-auto">
                                <div class="form-group" style="width: 200px;">
                                    <label for="dateRange">Delivery Date</label>
                                    <input type="text" id="dateRange" name="date_range"
                                           class="form-control" placeholder="Select Date Range"
                                           value="<?php echo e(request('date_range', $defaultFrom.' to '.$defaultTo)); ?>">
                                </div>
                            </div>
                            <div class="col-sm-auto">
                                <div class="form-group">
                                    <label for="delivery_boy">Delivery Boy</label>
                                    <select id="delivery_boy" name="delivery_boy" class="custom-select">
                                        <option value="">-- ALL --</option>
                                        <?php $__currentLoopData = $delivery_boys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($b->id); ?>"
                                                <?php echo e(request('delivery_boy') == $b->id ? 'selected' : ''); ?>

                                            ><?php echo e($b->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-auto">
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select id="status" name="status" class="custom-select">
                                        <option value="">-- ALL --</option>
                                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="delivered"<?php echo e(request('status') == 'delivered' ? 'selected' : ''); ?>>Delivered</option>
                                        <option value="reschedule_requested"<?php echo e(request('status') == 'reschedule_requested' ? 'selected' : ''); ?>>Reschedule Requested</option>
                                        <option value="rescheduled"<?php echo e(request('status') == 'rescheduled' ? 'selected' : ''); ?>>Rescheduled</option>
                                        <option value="cancel_requested"<?php echo e(request('status') == 'cancel_requested' ? 'selected' : ''); ?>>Cancel Requested</option>
                                        <option value="cancelled"<?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn bg-white border-left border-top border-top-sm-0 rounded-top-0 rounded-top-sm rounded-left-sm-0"><i class="material-icons text-primary icon-20pt">refresh</i>
                    </button>

                </div>
            </form>

            <div class="card">
                <h5 class="card-header">Deliveries</h5>
                <div class="card-body">
                    <table id="deliveriesTable" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Delivery Boy</th>
                            <th>Invoice No</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->deliveryBoy->name); ?></td>
                                <td><?php echo e($d->invoice_no); ?></td>
                                <td><?php echo e($d->delivery_date->format('d M Y')); ?></td>
                                <td>₹ <?php echo e(number_format($d->amount, 2)); ?></td>
                                <td>
                                    <?php if($d->status == 'delivered'): ?>
                                        <span class="badge badge-success">Delivered</span>
                                    <?php elseif($d->status == 'pending'): ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Others</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.deliveries.show', $d)); ?>"
                                       class="btn btn-primary">
                                        View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        flatpickr("#dateRange", {
            mode: "range",
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "d-m-Y",
            maxDate: "today",
            defaultDate: [
                "<?php echo e(now()->startOfMonth()->toDateString()); ?>",
                "<?php echo e(now()->toDateString()); ?>"
            ]
        });
    </script>
    <script>
        $(document).ready(function () {

            $('#deliveriesTable').DataTable({
                pageLength: 10,
                lengthChange: false,
                ordering: true,
                searching: true,
                info: true,
                autoWidth: false,

                columnDefs: [
                    { orderable: false, targets: 5 } // Action column
                ]
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/deliveries/index.blade.php ENDPATH**/ ?>