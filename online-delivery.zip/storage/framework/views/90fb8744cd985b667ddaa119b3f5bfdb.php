<?php $__env->startSection('title', 'Delivery Boys'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mdk-drawer-layout__content page">
        <div class="container-fluid page__heading-container">
            <div class="page__heading d-flex align-items-center">
                <div class="flex">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="/admin/dashboard">
                                    <i class="fa fa-tachometer-alt"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Delivery Boys</li>
                        </ol>
                    </nav>
                    <h1 class="m-0">Delivery Boys</h1>
                </div>
                <a href="<?php echo e(route('admin.delivery_boys.create')); ?>" class="btn btn-success ml-3">Add New</a>
            </div>
        </div>
        <div class="container-fluid page__container">
            <div class="card">
                <h5 class="card-header">Delivery Boys</h5>
                <div class="card-body">
                    <table id="deliveryBoyTable" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Created</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $deliveryBoys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($boy->name); ?></td>
                                <td><?php echo e($boy->username); ?></td>
                                <td><?php echo e($boy->created_at->format('d M Y')); ?></td>
                                <td>
                                    <?php if($boy->is_active): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <form method="POST"
                                          action="<?php echo e(route('admin.delivery_boys.toggle', $boy)); ?>"
                                          onsubmit="return confirm('Change status?')">
                                        <?php echo csrf_field(); ?>

                                        <?php if($boy->is_active): ?>
                                            <button class="btn btn-sm btn-danger">
                                                Deactivate
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-success">
                                                Activate
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No records</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#deliveryBoyTable').DataTable({
                pageLength: 10,
                ordering: true,
                searching: true,
                lengthChange: false,

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/admin/delivery_boys/index.blade.php ENDPATH**/ ?>