<?php $__env->startSection('content'); ?>

    <h6>Settlement</h6>

    <div class="card text-center">
        <div class="card-body">
            <h3>₹ <?php echo e(number_format($total,2)); ?></h3>
            <p>Total Verified Amount</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobile.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/settlement.blade.php ENDPATH**/ ?>