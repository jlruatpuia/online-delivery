<div class="bottom-nav d-flex justify-content-around align-items-center">

    <a href="<?php echo e(route('mobile.dashboard')); ?>"
       class="text-center text-decoration-none text-dark">
        <i class="bi bi-house nav-icon"></i>
        <div class="small">Home</div>
    </a>

    <a href="<?php echo e(route('mobile.deliveries')); ?>"
       class="text-center text-decoration-none text-dark">
        <i class="bi bi-box-seam nav-icon"></i>
        <div class="small">Deliveries</div>
    </a>



    <a href="<?php echo e(route('mobile.scan')); ?>"
       class="text-center text-decoration-none text-dark">
        <i class="bi bi-qr-code-scan nav-icon"></i>
        <div class="small">Scan</div>
    </a>

    <a href="<?php echo e(route('mobile.settlement')); ?>"
       class="text-center text-decoration-none text-dark">
        <i class="bi bi-cash-stack nav-icon"></i>
        <div class="small">Settlement</div>
    </a>

    <a href="<?php echo e(route('mobile.profile')); ?>"
       class="text-center text-decoration-none text-dark">
        <i class="bi bi-person nav-icon"></i>
        <div class="small">Profile</div>
    </a>

</div>
<?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/partials/bottom-nav.blade.php ENDPATH**/ ?>