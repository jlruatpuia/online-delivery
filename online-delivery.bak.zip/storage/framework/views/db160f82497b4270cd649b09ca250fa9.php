<?php $__env->startSection('title', 'Settlement'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-5 pt-4">
    <div class="card shadow-sm">
        <div class="card-header">Settlement Submission</div>
        <div class="card-body">
            <form method="GET" class="row g-2 mb-3">
                <div class="col-6">
                    <input type="date"
                           name="from_date"
                           value="<?php echo e($from); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="col-6">
                    <input type="date"
                           name="to_date"
                           value="<?php echo e($to); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="col-12">
                    <button class="btn btn-outline-primary w-100">
                        Calculate
                    </button>
                </div>
            </form>
            <hr/>
            <?php if($from && $to): ?>
                <div class="card shadow-sm mb-3">
                    <div class="card-body text-center">
                        <div class="text-muted">Total Verified Amount</div>
                        <h3 class="text-success">
                            ₹ <?php echo e(number_format($totalAmount, 2)); ?>

                        </h3>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('mobile.settlement.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="from_date" value="<?php echo e($from); ?>">
                    <input type="hidden" name="to_date" value="<?php echo e($to); ?>">

                    <button class="btn btn-success w-100"
                        <?php echo e($alreadySubmitted ? 'disabled' : ''); ?>>
                        <?php echo e($alreadySubmitted
                            ? 'Settlement Already Submitted'
                            : 'Submit Settlement'); ?>

                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>


    <div class="card mt-3 mb-2">
        <div class="card-header">Recent Settlements</div>
        <?php $__empty_1 = true; $__currentLoopData = $previousSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settlement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card-body d-flex justify-content-between">
            <div>
                <div>
                    <?php echo e(\Carbon\Carbon::parse($settlement->from_date)->format('d-m-Y')); ?>

                    → <?php echo e(\Carbon\Carbon::parse($settlement->to_date)->format('d-m-Y')); ?>

                </div>
                <small class="text-muted">
                    <?php echo e(ucfirst($settlement->status)); ?>

                </small>
            </div>
            <strong>
                ₹ <?php echo e(number_format($settlement->total_amount, 2)); ?>

            </strong>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card-body">
                <div class="text-muted text-center">
                    No settlements yet
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobile.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\online-delivery\resources\views/mobile/settlement/index.blade.php ENDPATH**/ ?>